package com.enderscope.htmlwallpaper;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class GyroWallpaperService extends WallpaperService {
    @Override
    public Engine onCreateEngine() { return new GyroEngine(); }

    private class GyroEngine extends Engine implements SensorEventListener {
        private SensorManager sm;
        private Sensor sensor;
        private RenderThread thread;
        private SharedPreferences prefs;
        private volatile float tx = 0f, ty = 0f;
        private Float baseP = null, baseR = null;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            prefs = getSharedPreferences("GyroPrefs", MODE_PRIVATE);
            sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            if (sm != null) {
                sensor = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
                if (sensor == null) sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            }
        }

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            thread = new RenderThread(holder);
            thread.start();
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            super.onSurfaceChanged(holder, format, w, h);
            if (thread != null) thread.setSize(w, h);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            super.onVisibilityChanged(visible);
            if (visible) {
                baseP = null; baseR = null;
                if (sm != null && sensor != null) sm.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
                if (thread != null) thread.paused = false;
            } else {
                if (sm != null) sm.unregisterListener(this);
                if (thread != null) thread.paused = true;
            }
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            if (thread != null) { thread.running = false; thread.interrupt(); thread = null; }
        }

        @Override
        public void onSensorChanged(SensorEvent e) {
            float p, r;
            if (e.sensor.getType() == Sensor.TYPE_GAME_ROTATION_VECTOR) {
                float[] rm = new float[9], ori = new float[3];
                SensorManager.getRotationMatrixFromVector(rm, e.values);
                SensorManager.getOrientation(rm, ori);
                p = (float) Math.toDegrees(ori[1]);
                r = (float) Math.toDegrees(ori[2]);
            } else {
                r = -e.values[0] * 4.5f;
                p = e.values[1] * 4.5f;
            }
            if (baseP == null) { baseP = p; baseR = r; }
            baseP += (p - baseP) * 0.008f;
            baseR += (r - baseR) * 0.008f;
            tx = Math.max(-26f, Math.min(26f, r - baseR)) / 26f;
            ty = -Math.max(-26f, Math.min(26f, p - baseP)) / 26f;
        }

        @Override public void onAccuracyChanged(Sensor s, int a) {}

        private class RenderThread extends Thread {
            private final SurfaceHolder holder;
            volatile boolean running = true, paused = false;
            int sw = 1080, sh = 1920;
            float iw = 1080f, ih = 1920f;
            long lastLoad = -1;
            EGLDisplay dpy = EGL14.EGL_NO_DISPLAY;
            EGLContext ctx = EGL14.EGL_NO_CONTEXT;
            EGLSurface surf = EGL14.EGL_NO_SURFACE;
            int prog;
            int[] tex = new int[2];

            RenderThread(SurfaceHolder h) { this.holder = h; }
            void setSize(int w, int h) { this.sw = w; this.sh = h; }

            @Override
            public void run() {
                if (!initEGL()) return;
                initGL();
                float cx = 0f, cy = 0f;
                while (running) {
                    if (paused) { try { Thread.sleep(100); } catch (Exception ignored) {} continue; }
                    long up = prefs.getLong("updated", 0);
                    if (up != lastLoad) { loadTex(); lastLoad = up; }
                    cx += (tx - cx) * 0.09f;
                    cy += (ty - cy) * 0.09f;
                    GLES20.glViewport(0, 0, sw, sh);
                    GLES20.glUseProgram(prog);
                    GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uOffset"), cx, cy);
                    GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uRes"), sw, sh);
                    GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uImgRes"), iw, ih);
                    GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
                    EGL14.eglSwapBuffers(dpy, surf);
                    try { Thread.sleep(16); } catch (Exception ignored) {}
                }
                EGL14.eglTerminate(dpy);
            }

            private boolean initEGL() {
                dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
                int[] v = new int[2];
                EGL14.eglInitialize(dpy, v, 0, v, 1);
                int[] attr = { EGL14.EGL_RED_SIZE,8, EGL14.EGL_GREEN_SIZE,8, EGL14.EGL_BLUE_SIZE,8, EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_NONE };
                EGLConfig[] cfg = new EGLConfig[1];
                int[] num = new int[1];
                EGL14.eglChooseConfig(dpy, attr, 0, cfg, 0, 1, num, 0);
                ctx = EGL14.eglCreateContext(dpy, cfg[0], EGL14.EGL_NO_CONTEXT, new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION,2,EGL14.EGL_NONE}, 0);
                surf = EGL14.eglCreateWindowSurface(dpy, cfg[0], holder.getSurface(), new int[]{EGL14.EGL_NONE}, 0);
                return EGL14.eglMakeCurrent(dpy, surf, surf, ctx);
            }

            private void initGL() {
                float[] v = {-1,-1, 1,-1, -1,1, -1,1, 1,-1, 1,1};
                FloatBuffer fb = ByteBuffer.allocateDirect(v.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();
                fb.put(v).position(0);
                String vs = "attribute vec2 aPos;varying vec2 vUv;void main(){vUv=aPos*0.5+0.5;vUv.y=1.0-vUv.y;gl_Position=vec4(aPos,0.0,1.0);}";
                String fs = "precision highp float;varying vec2 vUv;uniform sampler2D uImg;uniform sampler2D uDep;uniform vec2 uOffset;uniform vec2 uRes;uniform vec2 uImgRes;" +
                        "vec2 cover(vec2 uv,vec2 s,vec2 i){float rs=s.x/max(1.0,s.y),ri=i.x/max(1.0,i.y);vec2 ns=rs<ri?vec2(i.x*s.y/i.y,s.y):vec2(s.x,i.y*s.x/i.x);vec2 o=(rs<ri?vec2((ns.x-s.x)/2.0,0.0):vec2(0.0,(ns.y-s.y)/2.0))/ns;return (uv*s/ns+o-0.5)/1.08+0.5;}" +
                        "void main(){vec2 buv=cover(vUv,uRes,uImgRes);const int S=16;float ss=1.0/float(S);vec2 duv=uOffset*0.05/float(S);vec2 cuv=buv-(uOffset*0.025);float h=1.0,d=texture2D(uDep,clamp(cuv,0.001,0.999)).r;" +
                        "for(int i=0;i<S;i++){if(h<=d)break;h-=ss;cuv+=duv;d=texture2D(uDep,clamp(cuv,0.001,0.999)).r;}" +
                        "gl_FragColor=texture2D(uImg,clamp(cuv,0.001,0.999));}";
                prog = GLES20.glCreateProgram();
                int sv = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER); GLES20.glShaderSource(sv, vs); GLES20.glCompileShader(sv);
                int sf = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER); GLES20.glShaderSource(sf, fs); GLES20.glCompileShader(sf);
                GLES20.glAttachShader(prog, sv); GLES20.glAttachShader(prog, sf); GLES20.glLinkProgram(prog); GLES20.glUseProgram(prog);
                int a = GLES20.glGetAttribLocation(prog, "aPos");
                GLES20.glEnableVertexAttribArray(a);
                GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 0, fb);
                GLES20.glGenTextures(2, tex, 0);
                loadTex();
            }

            private void loadTex() {
                File f1 = new File(getFilesDir(), "rgb.png");
                File f2 = new File(getFilesDir(), "depth.png");
                Bitmap b1 = f1.exists() ? BitmapFactory.decodeFile(f1.getAbsolutePath()) : Bitmap.createBitmap(10,10,Bitmap.Config.ARGB_8888);
                Bitmap b2 = f2.exists() ? BitmapFactory.decodeFile(f2.getAbsolutePath()) : Bitmap.createBitmap(10,10,Bitmap.Config.ARGB_8888);
                if (!f1.exists()) { b1.eraseColor(Color.parseColor("#0284C7")); b2.eraseColor(Color.GRAY); }
                iw = b1.getWidth(); ih = b1.getHeight();
                bind(b1, 0, "uImg"); bind(b2, 1, "uDep");
            }

            private void bind(Bitmap b, int u, String n) {
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + u);
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[u]);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0);
                GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, n), u);
            }
        }
    }
}