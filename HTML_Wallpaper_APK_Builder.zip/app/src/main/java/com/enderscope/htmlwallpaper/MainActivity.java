package com.enderscope.htmlwallpaper;

import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private TextView tvStatus;
    private SharedPreferences prefs;

    private final ActivityResultLauncher<String> htmlPicker =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) extractHtmlWallpaper(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvStatus = findViewById(R.id.tvStatus);
        prefs = getSharedPreferences("GyroPrefs", MODE_PRIVATE);

        findViewById(R.id.btnPickHtml).setOnClickListener(v -> htmlPicker.launch("text/html"));

        findViewById(R.id.btnApply).setOnClickListener(v -> {
            prefs.edit().putLong("updated", System.currentTimeMillis()).apply();
            try {
                Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        new ComponentName(this, GyroWallpaperService.class));
                startActivity(i);
            } catch (Exception e) {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            }
        });
    }

    private void extractHtmlWallpaper(Uri uri) {
        tvStatus.setText("Reading .HTML file...");
        new Thread(() -> {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                BufferedReader r = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append("\n");
                r.close();
                String content = sb.toString();

                Bitmap rgb = decodeBase64Var(content, "IMG_SRC");
                Bitmap depth = decodeBase64Var(content, "DEPTH_SRC");

                if (rgb != null && depth != null) {
                    savePng(rgb, "rgb.png");
                    savePng(depth, "depth.png");
                    prefs.edit().putLong("updated", System.currentTimeMillis()).apply();
                    runOnUiThread(() -> {
                        tvStatus.setText("✅ HTML Loaded! Now click Step 2 below.");
                        Toast.makeText(this, "HTML Wallpaper Ready!", Toast.LENGTH_SHORT).show();
                    });
                } else {
                    runOnUiThread(() -> tvStatus.setText("❌ Invalid HTML file format."));
                }
            } catch (Exception e) {
                runOnUiThread(() -> tvStatus.setText("❌ Error: " + e.getMessage()));
            }
        }).start();
    }

    private Bitmap decodeBase64Var(String html, String key) {
        Pattern p = Pattern.compile(key + "\\s*=\\s*\"data:image/[^;]+;base64,([^\"]+)\"");
        Matcher m = p.matcher(html);
        if (m.find()) {
            byte[] b = Base64.decode(m.group(1), Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(b, 0, b.length);
        }
        return null;
    }

    private void savePng(Bitmap bmp, String name) throws Exception {
        File f = new File(getFilesDir(), name);
        FileOutputStream fos = new FileOutputStream(f);
        bmp.compress(Bitmap.CompressFormat.PNG, 95, fos);
        fos.close();
    }
}